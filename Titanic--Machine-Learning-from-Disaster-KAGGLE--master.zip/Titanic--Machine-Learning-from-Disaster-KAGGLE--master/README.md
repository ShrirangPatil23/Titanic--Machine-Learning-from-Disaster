# Titanic--Machine-Learning-from-Disaster
This is my solution to the Kaggle competition, Titanic - Machine Learning from disaster.

The  dataset contains information on various attributes of the passengers in the RMS Titanic. Including their fate, i.e. Survived or Not Survived the sinking.

This solution uses the Naive Bayes algorithm, more specifically the Gaussian Naive Bayes from the Scikit Learn Library.
